<template>
  <commenCom>
    <el-alert title="添加商品信息" type="info" center show-icon> </el-alert>
    <el-steps
      :active="activeIndex"
      align-center
      class="el_steps"
      finish-status="success"
    >
      <el-step title="基本信息"></el-step>
      <el-step title="商品参数"></el-step>
      <el-step title="商品属性"></el-step>
      <el-step title="商品图片"></el-step>
      <el-step title="商品内容"></el-step>
      <el-step title="完成"></el-step>
    </el-steps>
    <el-tabs
      tab-position="left"
      style="height: 200px; margin-top: 20px"
      @tab-click="tabclick"
    >
      <el-tab-pane label="基本信息">
        <el-form
          :label-position="labelPosition"
          label-width="80px"
          :model="basicInfoForm"
        >
          <el-form-item label="商品名称">
            <el-input v-model="basicInfoForm.name"></el-input>
          </el-form-item>
          <el-form-item label="商品价格">
            <el-input v-model="basicInfoForm.region"></el-input>
          </el-form-item>
          <el-form-item label="商品重量">
            <el-input v-model="basicInfoForm.type"></el-input>
          </el-form-item>
          <el-form-item label="商品数量">
            <el-input v-model="basicInfoForm.type"></el-input>
          </el-form-item>
          <el-form-item label="商品分类">
            <div class="block">
              <el-cascader
                v-model="cat_id"
                :props="{ value: 'cat_id', label: 'cat_name' }"
                :options="goodsClassifyList"
                @change="handleChange"
              >
              </el-cascader>
            </div>
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="商品参数">配置管理</el-tab-pane>
      <el-tab-pane label="商品属性">角色管理</el-tab-pane>
      <el-tab-pane label="商品图片">定时任务补偿</el-tab-pane>
      <el-tab-pane label="商品内容">定时任务补偿</el-tab-pane>
    </el-tabs>
  </commenCom>
</template>

<script>
import { getGoodsClassifyListApi } from '@/api/params'
import commenCom from '@/components/commenCom.vue'
export default {
  created () {
    // 步骤一 打开页面的时候，立即调用一次，获取商品分类数据列表的方法
    this.getGoodsClassifyList()
  },
  data () {
    return {
      activeIndex: 0,
      // 基本信息
      labelPosition: 'top',
      // 基本信息
      basicInfoForm: {
        name: '',
        region: '',
        type: ''
      },
      // 步骤一选择器中的数据
      goodsClassifyList: [],
      // 步骤一 获取商品分类数据传给后台的参数，一开始什么参数都为空
      goodsClassifyParams:
      {
        type: '',
        pagenum: '',
        pagesize: ''
      },
      cat_id: []
    }
  },
  methods: {
    tabclick (val) {
      console.log(val.index)
      this.activeIndex = Number(val.index)
    },
    // 步骤一选择器发生变化时执行的函数
    handleChange (value) {
      console.log(value)
    },
    // 步骤一选择器获取商品分类数据列表的方法
    async getGoodsClassifyList () {
      try {
        const res = await getGoodsClassifyListApi(this.goodsClassifyParams)
        console.log(res)
        this.goodsClassifyList = res.data.data
        console.log(this.goodsClassifyList)
      } catch (error) {
        console.log(error)
      }
    }
  },
  computed: {},
  watch: {},
  filters: {},
  components: { commenCom }
}
</script>

<style scoped>
.el_steps {
  margin-top: 20px;
}
:deep(.el-tabs--left, .el-tabs--right) {
  height: 100% !important;
}
</style>
